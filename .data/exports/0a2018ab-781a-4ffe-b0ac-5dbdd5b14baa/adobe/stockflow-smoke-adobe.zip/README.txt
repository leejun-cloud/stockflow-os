Upload the JPEG in Adobe Stock contributor portal.
Paste ordered keywords exactly as provided.
Confirm release attachment before final submit.